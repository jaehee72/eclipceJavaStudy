package ch01.ex01.case02;

public class Product {
	public static void main(String[] args) {
		// 필드_멤버변수
		int num;
		String sort;
		String name;
		int salesPrice;
		String regDate;
		String image;
	}
}
