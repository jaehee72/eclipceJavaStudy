package ch01.ex01.case02;

public class Board {
	public static void main(String[] args) {
		
		int seq;
		String title;
		String content;
		int hit;
		String regDate;
		String writer;
	}
}
