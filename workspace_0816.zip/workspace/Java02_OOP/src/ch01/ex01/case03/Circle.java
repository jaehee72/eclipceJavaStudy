package ch01.ex01.case03;

public class Circle {
	// 멤버 변수
	int radius;
	String name;
	
	// 메소드
	double getArea() {
		double area = radius * radius * 3.14;
		return area;
	}
}
