package ch05;

public class C09TwoDArray2 {
	public static void main(String[] args) {
		
		int[][] arr = new int[3][4];
		int num = 1;
		
		// 배열에 값을 저장
		for (int i=0; i<arr.length; i++) {
			for (int j=0; j<arr[i].length; j++) {
				arr[i][j] = num;  
				num++;
			}
		}
		
		// 배열의 값을 출력
		for (int i=0; i<arr.length; i++) {
			for (int j=0; j<arr[i].length; j++) {
				System.out.print(arr[i][j] + "\t");
			}
			System.out.println();
		}
	}
}
// a[0][0] a[0][1] a[0][2] a[0][3]
// a[1][0] a[1][1] a[1][2] a[1][3]
// a[2][0] a[2][1] a[2][2] a[2][3]