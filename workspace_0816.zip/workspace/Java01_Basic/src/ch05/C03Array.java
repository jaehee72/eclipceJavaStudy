package ch05;

public class C03Array {
	public static void main(String[] args) {
		
		// 자바는 배열을 객체로 다룬다.
		// 배열이 객체라는 증거
		int[] ints = new int[3];
		System.out.println(ints);
		
		String[] strs = new String[3];
		System.out.println(strs);
	}
}
