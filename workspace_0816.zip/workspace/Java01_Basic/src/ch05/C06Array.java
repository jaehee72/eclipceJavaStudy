package ch05;

public class C06Array {
	public static void main(String[] args) {
		
		int[] ints = {1,2,3,4,5};
		int sum = 0;
		
		for (int i=0; i<ints.length; i++) {
			int num = ints[i];
			sum += num;
			System.out.print(num + " ");
		}
		System.out.println("\n합: " + sum);

		for (int num : ints) {
			sum += num;
			System.out.print(num + " ");
		}
		System.out.println("\n합: " + sum);
	}
}
