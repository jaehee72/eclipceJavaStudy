package ch05;

public class C02Array {
	public static void main(String[] args) {
		
		// 배열 선언 방법
		int a[];
		a = new int[3];
		
		int b[] = new int[3];
		
		int c[] = {10, 20, 30};
		
		int d[] = new int[] {10, 20, 30};
		
		// 주의
		int e[];
//		e = {10, 20, 30};  // ERROR (배열선언과 동시에 초기화할 때만 가능)
		
		int[] array = {1, 2, 3};
		
//		System.out.printf();  // 1 2 3
	}
}
