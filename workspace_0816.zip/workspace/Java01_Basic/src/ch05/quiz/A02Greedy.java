/*
 * Q. 가게에 간 철수는 8370원 어치 물건을 구매하였다.
 * 철수에게는 500원, 100원, 50원, 10원 짜리 동전이 각 20개씩 있다.
 * 철수는 금액을 지불할 때 단위가 큰 동전부터 지불하려고 한다.
 * 철수가 지불하게 되는 각 동전의 개수를 구하시오.
 * (출력)
 * 500원짜리는 16개가 필요합니다.
 * 100원짜리는 ??개가 필요합니다.
 * 50원짜리는 ??개가 필요합니다.
 * 10원짜리는 2개가 필요합니다.
 */
package ch05.quiz;

public class A02Greedy {
	public static void main(String[] args) {
		
		int[] coins = {500, 100, 50, 10};
		int price = 8370;
		int count;  // 사용된 각 동전의 개수
		
		for (int i=0; i<coins.length; i++) {
			count = 0;
			count += price / coins[i];
			price = price % coins[i];
			
			System.out.println(coins[i] + "짜리 동전은 " + count + "가 필요합니다.");
		}
	}
}
