package ch05.quiz;

public class Quiz04 {
	public static void main(String[] args) {
		
		int[] scores = {79, 88, 91, 33, 100, 55, 95};
		
		int max = scores[0];  // 79 기준
		int min = scores[0];  // 79 기준
		
		for (int score : scores) {
			if (score > max) max = score;  // max: 79 88 91
			if (score < min) min = score;  // min: 79 79 79 33
		}
		
		System.out.printf("최대값: %d, 최소값: %d", max, min);
	}
}
