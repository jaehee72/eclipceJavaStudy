/*
 * Q. 20세부터 100세 이하의 사람들이 어느 한 장소에 머물고 있다고 할 때
 *   각 연령대별 인원이 몇명씩인지 체크해보세요.
 * 	 - { 55, 40, 27, 99, 76, 81, 29, 31, 33, 62 }
 *   - 배열, for문, 조건문 이용
 *   
 *    (출력)
 * 	  10명 중 20대는 2명입니다.
 *    10명 중 30대는 2명입니다.
 *    ...
 *    10명 중 90대는 1명입니다.
 */
package ch05.quiz;

public class A03CountOfNumber {
	public static void main(String[] args) {
		
		int[] people = { 55, 40, 27, 99, 76, 81, 29, 31, 33, 62 };
		int[] ages = new int[10];
		
		for (int i=0; i<people.length; i++) {
			int age = people[i];
			if (age < 30) ages[0]++;
			else if (age < 40) ages[1]++;
			else if (age < 50) ages[2]++;
			else if (age < 60) ages[3]++;
			else if (age < 70) ages[4]++;
			else if (age < 80) ages[5]++;
			else if (age < 90) ages[6]++;
			else if (age < 100) ages[7]++;
		}
		
		int number = people.length;
		System.out.println(number + "명 중 20대는 " + ages[0] + "명입니다.");
		System.out.println(number + "명 중 30대는 " + ages[1] + "명입니다.");
		System.out.println(number + "명 중 40대는 " + ages[2] + "명입니다.");
		System.out.println(number + "명 중 50대는 " + ages[3] + "명입니다.");
		System.out.println(number + "명 중 60대는 " + ages[4] + "명입니다.");
		System.out.println(number + "명 중 70대는 " + ages[5] + "명입니다.");
		System.out.println(number + "명 중 80대는 " + ages[6] + "명입니다.");
		System.out.println(number + "명 중 90대는 " + ages[7] + "명입니다.");
	}
}
