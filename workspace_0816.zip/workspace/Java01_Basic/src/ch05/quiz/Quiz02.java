package ch05.quiz;

import java.util.Scanner;

public class Quiz02 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("인원수 입력: ");
		int num = sc.nextInt();
		
		String name[] = new String[num];
		String telnum[] = new String[num];
		
		for (int i=0; i<name.length; i++) {
			System.out.println("\n### " + (i+1) + " ###");
			System.out.print("이름 입력: ");
			name[i] = sc.next();
			System.out.print("전화번호 입력: ");
			telnum[i] = sc.next();
		}
		
		for (int i=0; i<num; i++) {
			System.out.println("\n### " + (i+1) + " ###");
			System.out.println("이름: " + name[i]);
			System.out.println("전화번호: " + telnum[i]);
		}
		System.out.println();
		
		// Enhanced For문 (자루 구조 알고리즘_for-each문)
		for (String s : name) {
			System.out.print(s + " ");
		}
	}
}
