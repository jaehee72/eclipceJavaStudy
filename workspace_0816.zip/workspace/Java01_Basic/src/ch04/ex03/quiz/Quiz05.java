package ch04.ex03.quiz;

public class Quiz05 {
	public static void main(String[] args) {
		// 369
		for (int i=1; i<10; i++) {
			System.out.print(" " + i);
			if (i%3 == 0) System.out.println("짝");
		}
	}
}
