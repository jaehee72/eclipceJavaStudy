package ch04.ex03.quiz;

public class Quiz06 {
	public static void main(String[] args) {
		
		for (int i=1; i<=9; i++) {
			for (int j=0; j<=9; j++) {
				System.out.printf("%d%d\n", i, j);
			}
		}
	}
}