package ch04.ex03;

public class C01For {
	public static void main(String[] args) {
		
		// for (초기화식; 조건식; 증감식) { 실행문 }
		// 특정 조건에 맞춰서 정해진 반복횟수를 반복한다.
		// 반복횟수가 정해진 반복을 많이 한다.
		for (int i=0; i<10; i++) {
			System.out.print(i + " ");
		}		
	}
}
