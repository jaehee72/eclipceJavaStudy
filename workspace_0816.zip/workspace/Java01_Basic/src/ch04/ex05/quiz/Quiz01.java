package ch04.ex05.quiz;

import java.util.Scanner;

public class Quiz01 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int a;
		int b;
		int result = 0;
		
		do {
			// presentation logic
			System.out.print("숫자1: ");
			a = sc.nextInt();
			System.out.print("숫자2: ");
			b = sc.nextInt();
			
			// business logic
			result = a + b;
			
			System.out.printf("%d + %d = %d\n", a, b, result);
		} while(result != 0);
		
		System.out.println("합계가 0이므로 프로그램을 종료합니다.");
	}
}
