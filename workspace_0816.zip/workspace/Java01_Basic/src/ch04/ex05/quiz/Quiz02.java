package ch04.ex05.quiz;

import java.util.Scanner;

public class Quiz02 {
	public static void main(String[] args) {
		// 숫자 맞히기
		Scanner sc = new Scanner(System.in);
		int guess = 0;
		int tries = 0;
		int target = (int)(Math.random() * 100) + 1;
		String msg = "";
		
		do {
			System.out.print("입력: ");
			guess = sc.nextInt();
			tries++;
			
			if (guess > target)
				msg = "더 큰 수를 말했군요.";
			else if (guess < target)
				msg = "더 작은 수를 말했군요.";
			
			System.out.println(msg);
		} while(guess != target);  // 내가 답을 맞히지 못했다면 계속 반복
		
		System.out.printf("%d번만에 %d를 맞혔습니다.", tries, target);
	}
}
