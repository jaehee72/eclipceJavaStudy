package ch04.ex04;

public class C01While {
	public static void main(String[] args) {
		
		// for문: 수치에 대한 반복
		// while문: 조건에 대한 반복
		// while(조건) { 반복할 문장 }
		
		int i = 0;  // 시작값
		while (i < 5) {  // 종료식
			System.out.println(i);
			i++;  // 증감식
		}
		
		System.out.println(i);
	}
}
