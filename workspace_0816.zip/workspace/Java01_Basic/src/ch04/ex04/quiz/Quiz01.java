package ch04.ex04.quiz;

public class Quiz01 {
	public static void main(String[] args) {
		// 1 ~ 100까지의 합
		int sum = 0;
		
		for (int i=1; i<=100; i++) {
			sum += i;
		}
		System.out.println(sum);
		
		int i = 1;
		sum = 0;
		
		while (i<101) {
			sum += i;
			i++;
		}
		System.out.println(sum);
	}
}
