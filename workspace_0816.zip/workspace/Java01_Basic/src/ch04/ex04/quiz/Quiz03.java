package ch04.ex04.quiz;

public class Quiz03 {
	public static void main(String[] args) {
		
		int amount = 30_000;
		int expense = 0;  // 회당 꺼낸 금액
		int sum = 0;	  // 꺼낸 금액의 합
		int cnt = 0;	  // 꺼낸 횟수
		
		while(sum < amount) {
			cnt++;
			expense = (int)(Math.random() * 10 + 1) * 1000;
			System.out.printf("%d번째 %d원\n", cnt, expense);
			sum += expense;
		}
		
		System.out.printf("지갑에서 %d번에 걸쳐 총 %d원을 꺼냈습니다.", cnt, sum);
	}
}
