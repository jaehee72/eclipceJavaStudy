package ch04.ex01;

public class C01If {
	public static void main(String[] args) {
		
		int num1 = 10;
		int num2 = 5;
		
		if (num1 > num2) {  // if문: 조건식이 참이면 블록 안의 실행문이 실행. 거짓이면 실행되지 않는다.
			System.out.println("참입니다.");;
		}
	}
}
