package ch01.ex02;

public class C01Variable {	
	public static void main(String[] args) {
		
		int num;  // 변수 선언: [데이터 타입] [변수명]
		num = 1;  // 값 저장(변수 초기화)
		System.out.println(num);  // 1
		
		num = 0;
		System.out.println(num);  // 0
		
//		int num;  // 같은 메소드 내에서 같은 이름의 변수명 선언 X
		
		int num2 = 2;  // 변수 선언과 동시에 초기화
		System.out.println(num2);  // 2
		
		int a, b;
		a = 1;
		b = 2;
		
		int c = 3, d = 4;
	}
}
