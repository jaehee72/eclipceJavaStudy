package ch01.quiz;

public class Quiz02 {
	public static void main(String[] args) {
		
		int i = 300;
		double d = 1.2345;
		char c = 'A';
		boolean b = true;
		
		System.out.println("정수: " + i);
		System.out.println("실수: " + d);
		System.out.println("문자: " + c);
		System.out.println("논리: " + b);
	}
}
