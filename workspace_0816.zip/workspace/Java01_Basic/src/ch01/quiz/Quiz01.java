package ch01.quiz;

public class Quiz01 {
	public static void main(String[] args) {
		
		System.out.println("Quiz01 Class 출력");  // sysout ctrl+space
	}
}
// ctrl+D