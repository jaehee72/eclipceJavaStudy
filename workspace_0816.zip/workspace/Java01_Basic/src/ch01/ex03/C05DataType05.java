package ch01.ex03;

public class C05DataType05 {
	public static void main(String[] args) {
		
		// 논리 타입과 리터럴
		boolean b1 = true;
		System.out.println(b1);
		
		boolean b2 = false;
		System.out.println(b2);
	}
}
