package ch03.ex01;

public class C05Random {
	public static void main(String[] args) {
		
		// Math.random() 사용해 1 이상 10이하의 정수값 출력
		int result = (int)(Math.random() * 10) + 1;
		System.out.println(result);
	}
}
