package ch03.ex01;

public class C01Arithmetic {
	public static void main(String[] args) {
		
		// 산술 연산자: + - * / %
		int a = 10;
		int b = 3;
		
		System.out.println(a + b);
		System.out.println(a - b);
		System.out.println(a * b);
		System.out.println(a / b);  // 3  int / int -> int
		System.out.println(a % b);  // 1
	}
}
