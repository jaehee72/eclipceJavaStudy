package ch03.ex01.quiz;

public class Quiz02 {
	public static void main(String[] args) {
		
		double f = 3.141592;
		
		int result = (int) (f - f % 1);  //  소수점 이하를 턺
		System.out.println(result);
	}
}
