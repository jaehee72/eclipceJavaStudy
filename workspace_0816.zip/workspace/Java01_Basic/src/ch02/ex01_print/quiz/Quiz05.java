package ch02.ex01_print.quiz;

public class Quiz05 {
	public static void main(String[] args) {
		
		System.out.printf("%d%c %s %d%c", 2022, '년', "8월", 9, '일');
	}
}
