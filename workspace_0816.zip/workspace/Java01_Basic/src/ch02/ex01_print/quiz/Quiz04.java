package ch02.ex01_print.quiz;

public class Quiz04 {
	public static void main(String[] args) {
		
		int first = 10;
		int second = 4826;
		int third = 8905;
		
		System.out.printf("휴대폰 번호: %03d-%04d-%04d", first, second, third);
	}
}
