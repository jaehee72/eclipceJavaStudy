package ch02.ex01_print.quiz;

public class Quiz06 {
	public static void main(String[] args) {
		
		System.out.println("\t\t회비 정보");
		System.out.println("====================================");
		System.out.println("이름\t나이\t\t회비");
		System.out.println("====================================");
		System.out.println("배수지\t27\t\t￦20,000");
		System.out.println("정국\t30\t\t￦30,000");
		System.out.println("아이린\t29\t\t￦50,000");
		System.out.println("====================================");
		System.out.println("합\t계\t\t￦100,000");
	}
}
