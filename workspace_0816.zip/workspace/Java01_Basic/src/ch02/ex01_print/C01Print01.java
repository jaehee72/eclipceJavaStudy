package ch02.ex01_print;

public class C01Print01 {
	public static void main(String[] args) {
		
		// println(): 출력 후 줄 바꿈
		System.out.println("hello");
		
		// print(): 출력
		System.out.print("hello");
		
		// printf(): 포맷 형식으로 출력
		System.out.printf("hello");
	}
}
