package ch02.ex01_print;

public class C04Print04 {
	public static void main(String[] args) {
		
		// 이스케이프 \t - TAB만큼 이동
		System.out.println("\t9");
		System.out.println("1\t9");
		System.out.println("12\t9");
		System.out.println("123\t9");
		System.out.println("1234\t9");
		System.out.println("12345\t9");
		System.out.println("123456\t9");
		System.out.println("1234567\t9");
		System.out.println("12345678\t9");
	}
}
