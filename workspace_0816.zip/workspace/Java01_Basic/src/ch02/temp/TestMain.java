package ch02.temp;

public class TestMain {
	public static void main(String[] args) {
		
		Lion leo = new Lion();
		leo.run();
	}
}
