package ch02.temp;

public class Lion {
	
	// 필드
	double weight;
	double height;
	
	// 메소드
	public void run() {
		System.out.println("사자가 달린다.");
	}
}
