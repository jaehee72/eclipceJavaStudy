package ch01.ex02.quiz.case06;

public class Score {
	
	String name;
	int score;
}
