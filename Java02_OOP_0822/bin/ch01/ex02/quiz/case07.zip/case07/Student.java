package ch01.ex02.quiz.case07;

public class Student {
	
	int studentId;
	String name;
	String major;
}
