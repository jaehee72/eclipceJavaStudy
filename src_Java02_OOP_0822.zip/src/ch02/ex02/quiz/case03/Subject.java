package ch02.ex02.quiz.case03;

public class Subject {
	
	int subjectID;
	String subjectName;
	int score;
}
