package ch02.ex01.case01;

public class StudentMain {
	public static void main(String[] args) {
		
		Student s = new Student();
		
		s.showStudentInfo();
	}
}
