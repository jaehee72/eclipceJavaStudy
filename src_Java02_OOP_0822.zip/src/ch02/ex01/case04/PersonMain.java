package ch02.ex01.case04;

public class PersonMain {
	public static void main(String[] args) {
		
		Person p = new Person();
		
		System.out.println(p.name);
	}
}
