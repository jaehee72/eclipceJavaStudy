package ch03.ex01.case01;

public class Card {
	
	String shape;
	int number;
	
	static int width;
	static int height;
}
