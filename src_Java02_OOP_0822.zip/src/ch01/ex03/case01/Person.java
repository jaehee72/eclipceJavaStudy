package ch01.ex03.case01;

public class Person {
	
	String name;
	int age;
	
	void setName(String myName) {
		name = myName;
	}
	void setAge(int myAge) {
		age = myAge;
	}
	
	String getName() {
		return name;
	}
	int getAge() {
		return age;
	}
}
