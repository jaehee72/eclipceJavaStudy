package ch01.ex01.case04;

public class Student {
	
	String name;
	int kor;
	int eng;
	int math;
	int sum;
	double avg;
}
