package ch01.ex01.quiz.case03;

import java.util.Scanner;

public class Student {

	String name;
	int kor;
	int eng;
	int math;
	int sum;
	double avg;
	
	public void input() {
		Scanner sc = new Scanner(System.in);
		System.out.print("이름 입력: ");
		name = sc.next();
		System.out.print("국어 점수 입력: ");
		kor = sc.nextInt();
		System.out.print("영어 점수 입력: ");
		eng = sc.nextInt();
		System.out.print("수학 점수 입력: ");
		math = sc.nextInt();
		
		sum = kor + eng + math;
		avg = sum / 3.0;
	}
	
	public void output() {
		System.out.println("이름: " + name);		
		System.out.println("총점: " + sum);	
		System.out.println("평균: " + avg);	
	}
}
