package ch01.ex02.quiz.case02;

public class Drink {

	String name;  // 음료 이름
	int sumPay;	  // 총 판매 금액
	int sumCnt;	  // 총 판매 수량
}
