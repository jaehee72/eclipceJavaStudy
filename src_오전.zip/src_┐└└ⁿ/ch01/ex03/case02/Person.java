package ch01.ex03.case02;

public class Person {
	// 필드
	private String name;
	private int age;
	
	public void setName(String myName) {
		name = myName;
	}
	public void setAge(int myAge) {
		age = myAge;
	}
	
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
}
