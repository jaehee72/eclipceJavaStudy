package ch01.ex02.arrayList.case01;

public class Book {
	
	String title;
	String author;
	
	void showBookInfo() {
		System.out.println(title + ", " + author);
	}
}
