package ch01.ex02.quiz.case04;

public class Student {
	
	String name;
	int kor;
	int eng;
	int math;
	int sum;
	double avg;
}
