package ch01.ex02.quiz.case05;

public class Book {
	
	String name;
	String author;
	int price;
}
