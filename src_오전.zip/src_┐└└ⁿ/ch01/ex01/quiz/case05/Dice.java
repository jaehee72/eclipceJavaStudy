package ch01.ex01.quiz.case05;

public class Dice {
	
	public int roll() {
		return (int)(Math.random() * 6) + 1;
	}
}
