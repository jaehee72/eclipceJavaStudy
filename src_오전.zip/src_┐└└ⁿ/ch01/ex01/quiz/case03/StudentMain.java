package ch01.ex01.quiz.case03;

public class StudentMain {
	public static void main(String[] args) {
		
		Student s1 = new Student();
		
		s1.input();
		s1.output();
		
		Student s2 = new Student();
		
		s2.input();
		s2.output();
	}
}
