package ch01.ex01.case01;

public class Student {	
	// 멤버 변수(속성)_필드
	int studentNumber;
	String studentName;
	int majorCode;
	String majorName;
	int grade;
}
